"""
Dijkstra's algorithm

What is it?
It is a greedy algorithm used in directed graphs to calculate the
shortest path to every vertex from the given vertex, when the edges in the
graph have non-negative weights associated with them.

For example, imagine a network of roads between a bunch of cities.
Each road has a certain length. In such a network, Dijkstra's can be used to
calculate the shortest path from a city to every other city.

When all edges have the same weight, however, BFS gets the job done.

How does it work?
Start from the given vertex 'V'.
Assume that the distance to every other vertex in the graph is INF (infinite or
INT_MAX for implementation sake) and the distance to V itself is 0.
Update the distances to the direct neighbors of V.
Mark V as exhausted.
Identify the vertex currently closest to V. Let's call it CV.
Go to CV and update the distances to all neighbors of CV.
Mark CV as exhausted.
Now go to the vertex that has not been exhausted and is closest to V.
Repeat the same process that we did for CV.
Repeat until all vertices are exhausted.

Why do we need to mark vertices as exhausted?
To make sure we don't consider them when looking for the next closest vertex.

How long does it take to run?
For a graph with V vertices and E edges,
In our implementation - O(E + V.logV)
In the original implementation of Dijkstra's - O(V^2)
The reason being that, in the original implementation, we look at all vertices
to identify the next vertex to go to whereas in our implementation we use a
min-heap.
"""
from priority_queue import MinPriorityQueue


# Vertex definition
class Vertex(object):

    def __init__(self, val):
        self.val = val

        # The list of neighbors could be stored in many ways
        # A list of 'pairs' with neighbor vertex and the weight of the edge
        # between this vertex and the neighbor
        # Or, as we are going to implement here, it can be a mapping from
        # neighbor to the weight of the edge between them
        self.neighbors = {}  # Mapping from neighbor to the edge weight

    def __repr__(self):
        return '%s' % self.val


# Dijkstra's implementation
# The following is the implementation for a graph with the vertices as defined
# above. One of the more standard graph representations used to illustrate
# Dijkstra's is Adjacency Matrix. Mat[i][j] contains the edge weight between
# i and j in that case.
# Regardless of how the graph is implemented, the idea is the same.
def dijkstras(v):
    pq = MinPriorityQueue()
    pq.insert(v, 0)

    # Mapping from vertices to their distance from v
    # Any vertex not in this dict is effectively at an infinite distance
    distances = {}
    prev = {}

    exhausted = set()
    while not pq.empty():
        element = pq.pop()
        vertex = element.val
        dist = element.priority
        distances[vertex] = min(dist, distances.get(vertex, float('inf')))
        exhausted.add(vertex)
        for neighbor, weight in vertex.neighbors.items():
            if neighbor in exhausted:
                continue
            if (dist + weight) < distances.get(neighbor, float('inf')):
                prev[neighbor] = vertex
                distances[neighbor] = dist + weight
            pq.set_priority(neighbor, distances[neighbor])

    print 'Distances:'
    print distances

    for vertex in distances.keys():
        print 'Path from %s to %s: %s' % (v, vertex,
                                          _trace_path(v, vertex, prev))


def _trace_path(start, end, prev_dict):
    path = []
    curr = end
    while curr != start:
        path.append(curr)
        curr = prev_dict[curr]
    path.append(start)
    return list(reversed(path))


if __name__ == '__main__':
    """
    Let's try to model the graph below and see the shortest paths
    to every vertex from 1.

          (2)
        2 --- 4
      /(13)  /  \
    1       /(11)\ (3)
      \(6) /      \
        3 -------- 5
              (4)
    """
    v1 = Vertex(1)
    v2 = Vertex(2)
    v3 = Vertex(3)
    v4 = Vertex(4)
    v5 = Vertex(5)

    v1.neighbors = {
        v2: 13,
        v3: 6,
    }
    v2.neighbors = {
        v4: 2,
    }
    v3.neighbors = {
        v4: 11,
        v5: 4,
    }
    v4.neighbors = {
        v5: 3,
    }

    dijkstras(v1)
