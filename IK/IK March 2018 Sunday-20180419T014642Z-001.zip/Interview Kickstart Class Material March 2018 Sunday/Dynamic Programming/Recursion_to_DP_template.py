"""
Quick template on how to turn a recursive solution in to a DP solution
"""


def solution(constant1, param1, constant2, param2):
    """
    A recursive solution to the given problem.
    Let's say param1 goes from 0 to length of constant1.
    Let's say param2 goes from length of constant2 - 1 to 0.
    """
    if param1 == len(constant1) and param2 == 0:
        return 1
    if param1 == len(constant1):
        return 2
    if param2 == 0:
        return 3

    return (
        solution(constant1, param1+1, constant2, param2) +
        solution(constant1, param1, constant2, param2-1) +
        solution(constant1, param1+1, constant2, param2-1)
    )


def dp_solution(constant1, constant2):
    """
    DP solution for the given problem
    """
    # Notice how the DP table name is same as the recursive function name
    solution = []

    # We want the param1 values to be 0 to len(constant1), inclusive,
    # Because of what our base case is.
    for param1 in xrange(len(constant1)+1):
        solution.append([0] * len(constant2))

    # Now fill in the base case values
    # Notice how we want to do the assignment in the reverse order
    # of the base conditions.

    # When param2 is 0
    for param1 in xrange(len(solution)):
        solution[param1][0] = 3

    # When param1 is len(constant1)
    for param2 in solution[len(constant1)]:
        solution[len(constant1)][param2] = 2

    # When param1 is len(constant1) and param2 is 0
    solution[len(constant1)][0] = 1

    # Since param1 was going from 0 to len(constant1) in recursion,
    # We go the other way here.
    for param1 in xrange(len(constant1)-1, -1, -1):
        # Since param2 was going from len(constant2)-1 to 0 in recursion,
        # We go the other way here.
        for param2 in xrange(0, len(constant2)):
            # Notice how the equation is exactly what the recursion says it is
            solution[param1][param2] = (
                solution[param1+1][param2] +
                solution[param1][param2-1] +
                solution[param1+1][param2-1]
            )

    # We return the solution value for param1 = 0 and param2 = len(constant2)-1
    # Basically the values we start out with in our recursion
    return solution[0][len(constant2)-1]
